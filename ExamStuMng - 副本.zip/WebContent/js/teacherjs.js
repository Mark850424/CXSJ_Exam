/**
 * teacher端导航栏各选项跳转js
 */

function TLesson() {
    window.location.href = 'teacherPage.jsp'
}

function TAddG() {
    window.location.href = 'TAddGrade.jsp'
}

function TBrowseG() {
    window.location.href = 'TBrowseGrade.jsp'
}

function TBrowseFY(){
	window.location.href = 'TBrowsePaged.jsp'
}
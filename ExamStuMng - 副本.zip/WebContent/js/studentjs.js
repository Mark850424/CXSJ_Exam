/**
 * student端导航栏各选项跳转js
 */

function SChsLson() {
    window.location.href = 'SChooseLson.jsp'
}

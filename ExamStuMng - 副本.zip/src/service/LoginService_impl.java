package service;

import dao.UserDao;
import dao.UserDao_impl;
import user.User;

public class LoginService_impl implements LoginService {

	private UserDao dao;

	public LoginService_impl() {
		this.dao = new UserDao_impl();
	}

	@Override
	public int checkPassword(String username, String userpassword) {
		User user = new User();
		user.setUsername(username);
		user.setUserpassword(userpassword);
		user = dao.findByUsername(username);
		if (user == null)//没有这个用户
			return 2;
		String password = user.getUserpassword();
		if (password.equals(userpassword)) {//密码对，登录成功
			return 0;
		} else//密码错
			return 1;
	}

	@Override
	public int checkUsertype(String username) {
		User user = new User();
		user.setUsername(username);
		user = dao.findByUsername(username);
		if (user == null)
			return -1;
		int usertype = user.getUsertype();//有这个用户的话，就找这个用户的类型id并返回
		return usertype;
	}

	@Override
	public User getUser(String username) {
		UserDao_impl dao = new UserDao_impl();
		return dao.findByUsername(username);
	}

}

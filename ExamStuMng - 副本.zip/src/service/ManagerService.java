package service;

import user.Manager;
import user.StudentforUPDT;
import user.Teacher;

public interface ManagerService {
	Manager getManager(String name);

	int addTcLson(Teacher tc);

	int updateStuLson(StudentforUPDT stu);
}

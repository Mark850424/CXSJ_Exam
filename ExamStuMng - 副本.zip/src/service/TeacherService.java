package service;

import user.Student;
import user.Teacher;

public interface TeacherService {
	Teacher getLesson(String name);

	Teacher getTeacher(String name);

	int addStuGrade(Student stu);
}

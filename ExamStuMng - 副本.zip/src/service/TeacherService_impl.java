package service;

import dao.TeacerDao_impl;
import user.Student;
import user.Teacher;

public class TeacherService_impl implements TeacherService {

	@Override
	public Teacher getLesson(String name) {
		TeacerDao_impl dao = new TeacerDao_impl();
		return dao.findByTeachername(name);
	}

	@Override
	public Teacher getTeacher(String name) {
		TeacerDao_impl dao = new TeacerDao_impl();
		return dao.findByTeachername(name);
	}

	@Override
	public int addStuGrade(Student stu) {
		TeacerDao_impl dao = new TeacerDao_impl();
		return dao.addStuGrade(stu);
	}

}

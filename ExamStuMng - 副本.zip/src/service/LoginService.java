package service;

import user.User;

public interface LoginService {
	int checkPassword(String username, String userpassword);

	int checkUsertype(String username);

	User getUser(String username);
}

package service;

import user.Student;

public interface StudentService {
	Student getStudent(String name);

	int addChsLesson(String sid, String sname, String tname, String lid, String lname);
}

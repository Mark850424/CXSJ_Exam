package service;

import dao.ManagerDao_impl;
import user.Manager;
import user.StudentforUPDT;
import user.Teacher;

public class ManagerService_impl implements ManagerService {

	@Override
	public Manager getManager(String name) {
		ManagerDao_impl dao = new ManagerDao_impl();
		return dao.findByMngerName(name);
	}

	@Override
	public int addTcLson(Teacher tc) {
		ManagerDao_impl dao = new ManagerDao_impl();
		return dao.addTcLson(tc);
	}

	@Override
	public int updateStuLson(StudentforUPDT stu) {
		ManagerDao_impl dao = new ManagerDao_impl();
		return dao.updateStuLson(stu);
	}

}

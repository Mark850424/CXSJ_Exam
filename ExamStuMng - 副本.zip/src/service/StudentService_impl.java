package service;

import dao.StudentDao_impl;
import user.Student;

public class StudentService_impl implements StudentService {

	@Override
	public Student getStudent(String name) {
		StudentDao_impl dao = new StudentDao_impl();
		return dao.findStu(name);
	}

	@Override
	public int addChsLesson(String sid, String sname, String tname, String lid, String lname) {
		StudentDao_impl dao = new StudentDao_impl();
		return dao.addChsLesson(sid, sname, tname, lid, lname);
	}

}

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import user.Manager;
import user.StudentforUPDT;
import user.Teacher;
import util.DBUtil;

public class ManagerDao_impl implements ManagerDao {

	private Connection conn;
	private PreparedStatement ps;
	private String sql;

	{
		//获取DBUtril的连接
		try {
			conn = (new DBUtil()).getConnection();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
	}

	@Override
	public Manager findByMngerName(String name) {
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = st.executeQuery("SELECT userid, username FROM userlogin WHERE username = '" + name + "'");
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		while (true) {
			try {
				if (!rs.next())
					break;
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
			try {
				return new Manager(rs.getString("userid"), rs.getString("username"));
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
		}
		return null;
	}

	@Override
	//返回所有可授课的教师名字（从userlogin表）
	public List<Manager> findAllTeacher() {
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		List<Manager> lis = new ArrayList<Manager>();
		ResultSet rs = null;
		try {
			rs = st.executeQuery("SELECT userid,username FROM userlogin WHERE usertype='" + 1 + "'");
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		//每次读取一条记录
		while (true) {
			try {
				if (!rs.next())
					break;
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
			try {
				//添加到lis集合中
				lis.add(new Manager(rs.getString("userid"), rs.getString("username")));
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
		}
		return lis;
	}

	//添加教师任课（当一位老师已经任课了某门以后，则不可再添加）
	@Override
	public int addTcLson(Teacher tc) {
		sql = "INSERT INTO tlinfo(teachid,teachname,lessonid,lessonname) VALUES(?,?,?,?)";
		sql = "INSERT INTO tlinfo(teachid,teachname,lessonid,lessonname) SELECT '" + tc.getTeachId() + "','"
				+ tc.getTeachName() + "','" + tc.getLessonId() + "','" + tc.getLessonName()
				+ "' FROM tlinfo WHERE NOT EXISTS(SELECT * FROM tlinfo WHERE teachname='" + tc.getTeachName()
				+ "' AND lessonname='" + tc.getLessonName() + "') limit 1";
		try {
			//使用prepareStatement动态添加参数
			ps = conn.prepareStatement(sql);
			//			ps.setString(1, tc.getTeachId());
			//			ps.setString(2, tc.getTeachName());
			//			ps.setString(3, tc.getLessonId());
			//			ps.setString(4, tc.getLessonName());
			return ps.executeUpdate();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
			return 0;
		}
	}

	//@Override
	//返回所有学生的选课情况（不带索引）
	//	public List<Student> findAllStuLson() {
	//		Statement st = null;
	//		try {
	//			st = conn.createStatement();
	//		} catch (SQLException throwables) {
	//			throwables.printStackTrace();
	//		}
	//		List<Student> lis = new ArrayList<Student>();
	//		ResultSet rs = null;
	//		try {
	//			rs = st.executeQuery("SELECT stuid,stuname,teachname,lessonid,lessonname,lessongrade FROM scginfo");
	//		} catch (SQLException throwables) {
	//			throwables.printStackTrace();
	//		}
	//		//每次读取一条记录
	//		while (true) {
	//			try {
	//				if (!rs.next())
	//					break;
	//			} catch (SQLException throwables) {
	//				throwables.printStackTrace();
	//			}
	//			try {
	//				//添加到lis集合中
	//				lis.add(new Student(rs.getString("stuid"), rs.getString("stuname"), rs.getString("teachname"),
	//						rs.getString("lessonid"), rs.getString("lessonname"), rs.getString("lessongrade")));
	//			} catch (SQLException throwables) {
	//				throwables.printStackTrace();
	//			}
	//		}
	//		return lis;
	//	}

	@Override
	//返回所有学生的选课情况（带索引）
	public List<StudentforUPDT> findAllStuLson() {
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		List<StudentforUPDT> lis = new ArrayList<StudentforUPDT>();
		ResultSet rs = null;
		try {
			rs = st.executeQuery("SELECT tableid,stuid,stuname,teachname,lessonid,lessonname,lessongrade FROM scginfo");
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		//每次读取一条记录
		while (true) {
			try {
				if (!rs.next())
					break;
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
			try {
				//添加到lis集合中
				lis.add(new StudentforUPDT(rs.getInt("tableid"), rs.getString("stuid"), rs.getString("stuname"),
						rs.getString("teachname"), rs.getString("lessonid"), rs.getString("lessonname"),
						rs.getString("lessonname")));
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
		}
		return lis;
	}

	//更新学生的选课情况（可更新的为教师name、课程id、课程name）
	@Override
	public int updateStuLson(StudentforUPDT stu) {
		//根据userid更新数据
		sql = "UPDATE scginfo SET teachname= '" + stu.getTeachname() + "' , lessonid = '" + stu.getLessonid()
				+ "',lessonname = '" + stu.getLessonname() + "' WHERE tableid = '" + stu.getTableid() + "' AND stuid='"
				+ stu.getStuid() + "' AND stuname='" + stu.getStuname() + "'";

		Statement st = null;
		try {
			st = conn.createStatement();
			return st.executeUpdate(sql);
		} catch (SQLException throwables) {
			throwables.printStackTrace();
			return 0;
		}
	}

}

package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import user.Student;
import user.Teacher;
import util.DBUtil;

public class TeacerDao_impl implements TeacherDao {
	private Connection conn;
	private PreparedStatement ps;
	private String sql;

	{
		//获取DBUtril的连接
		try {
			conn = (new DBUtil()).getConnection();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
	}

	//查询某位老师教的所有内容（包括该老师的id、name、课id、课name）
	@Override
	public List<Teacher> findAllLesson(String name) {
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		List<Teacher> lis = new ArrayList<Teacher>();
		ResultSet rs = null;
		try {
			rs = st.executeQuery(
					"SELECT teachid, teachname ,lessonid,lessonname FROM tlinfo WHERE teachname = '" + name + "'");
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		//每次读取一条记录
		while (true) {
			try {
				if (!rs.next())
					break;
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
			try {
				//添加到lis集合中
				lis.add(new Teacher(rs.getString("teachid"), rs.getString("teachname"), rs.getString("lessonid"),
						rs.getString("lessonname")));
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
		}
		return lis;
	}

	//与上面不同的是这里仅返回单条记录，主要是为了获取教师名字
	@Override
	public Teacher findByTeachername(String name) {
		// TODO Auto-generated method stub
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = st.executeQuery(
					"SELECT teachid, teachname ,lessonid,lessonname FROM tlinfo WHERE teachname = '" + name + "'");
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		while (true) {
			try {
				if (!rs.next())
					break;
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
			try {
				return new Teacher(rs.getString("teachid"), rs.getString("teachname"), rs.getString("lessonid"),
						rs.getString("lessonname"));
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
		}
		return null;
	}

	//老师名+课名->学生情况
	public List<Student> findAllStudent(String tname, String lname) {
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		List<Student> lis = new ArrayList<Student>();
		ResultSet rs = null;
		try {
			rs = st.executeQuery(
					"SELECT stuid, stuname ,teachname,lessonid,lessonname,lessongrade FROM scginfo WHERE teachname = '"
							+ tname + "' AND lessonname='" + lname + "'");
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		//每次读取一条记录
		while (true) {
			try {
				if (!rs.next())
					break;
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
			try {
				//添加到lis集合中
				lis.add(new Student(rs.getString("stuid"), rs.getString("stuname"), rs.getString("teachname"),
						rs.getString("lessonid"), rs.getString("lessonname"), rs.getString("lessongrade")));
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
		}
		return lis;
	}

	//老师名->所有选了该老师的情况
	@Override
	public List<Student> findAllStuByTc(String tname) {
		// TODO Auto-generated method stub
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		List<Student> lis = new ArrayList<Student>();
		ResultSet rs = null;
		try {
			rs = st.executeQuery(
					"SELECT stuid, stuname ,teachname,lessonid,lessonname,lessongrade FROM scginfo WHERE teachname = '"
							+ tname + "'");
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		//每次读取一条记录
		while (true) {
			try {
				if (!rs.next())
					break;
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
			try {
				//添加到lis集合中
				lis.add(new Student(rs.getString("stuid"), rs.getString("stuname"), rs.getString("teachname"),
						rs.getString("lessonid"), rs.getString("lessonname"), rs.getString("lessongrade")));
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
		}
		return lis;
	}

	//录入未加入班级的学生信息+成绩
	@Override
	public int addStuGrade(Student stu) {
		//根据学生名、老师姓名、课程名称更新数据
		sql = "UPDATE scginfo SET lessongrade= '" + stu.getLessongrade() + "' WHERE stuname = '" + stu.getStuname()
				+ "' AND teachname='" + stu.getTeachname() + "' AND lessonname='" + stu.getLessonname() + "'";
		//可以加个更新失败的提示

		Statement st = null;
		try {
			st = conn.createStatement();
			return st.executeUpdate(sql);
		} catch (SQLException throwables) {
			throwables.printStackTrace();
			return 0;
		}
	}

}

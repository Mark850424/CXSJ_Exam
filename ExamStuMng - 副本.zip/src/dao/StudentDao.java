package dao;

import java.util.List;

import user.Student;
import user.Teacher;

public interface StudentDao {
	List<Student> findByStuName(String name);//通过学生名到scginfo寻找该学生的所有选课和成绩情况

	Student findStu(String name);//用于后续LoginController取学生名给前端${}用

	List<Teacher> findAllLesson();

	int addChsLesson(String sid, String sname, String tname, String lid, String lname);
}

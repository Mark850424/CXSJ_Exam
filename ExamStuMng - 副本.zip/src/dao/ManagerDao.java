package dao;

import java.util.List;

import user.Manager;
import user.StudentforUPDT;
import user.Teacher;

public interface ManagerDao {
	//教务人员的名字，后续LoginController传教务人员名字值用，由于教务人员其实就是登录需要用到其
	//数据库的一些字段，其余都是对教师、学生进行操作，因此不用专门创建一个Manager实体类，创建的话辅助区分层次吧
	Manager findByMngerName(String name);

	List<Manager> findAllTeacher();//查找所有老师返回到“录入老师任课界面”

	int addTcLson(Teacher tc);

	//List<Student> findAllStuLson();//查找所有学生选课情况返回到“修改学生选课界面”，这条返回不带索引的
	List<StudentforUPDT> findAllStuLson();//查找所有学生选课情况返回到“修改学生选课界面”，带唯一索引

	int updateStuLson(StudentforUPDT stu);//更新学生的选课情况
}

package dao;

import user.User;

public interface UserDao {
	User findByUsername(String name);//通过用户名查找用户
}

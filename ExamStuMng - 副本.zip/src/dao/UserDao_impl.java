package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import user.User;
import util.DBUtil;

public class UserDao_impl implements UserDao {

	private Connection conn;
	private PreparedStatement ps;
	private String sql;

	{
		//获取DBUtril的连接
		try {
			conn = (new DBUtil()).getConnection();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
	}

	//通过用户名查找用户
	@Override
	public User findByUsername(String name) {
		// TODO Auto-generated method stub
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = st.executeQuery(
					"SELECT userid, username ,userpassword,usertype FROM userlogin WHERE username = '" + name + "'");
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		while (true) {
			try {
				if (!rs.next())
					break;
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
			try {
				return new User(rs.getString("userid"), rs.getString("username"), rs.getString("userpassword"),
						rs.getInt("usertype"));
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
		}
		return null;
	}

}

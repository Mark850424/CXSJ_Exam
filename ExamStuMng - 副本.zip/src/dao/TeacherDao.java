package dao;

import java.util.List;

import user.Student;
import user.Teacher;

public interface TeacherDao {
	//Teacher findByTeachername(String name);//仅返回一条
	List<Teacher> findAllLesson(String name);//通过老师名到tlinfo寻找该老师所教授的所有课

	Teacher findByTeachername(String name);//找老师的名字，后续LoginController传教师名字值用

	List<Student> findAllStudent(String tname, String lname);//通过老师名+课名提取所有学生

	List<Student> findAllStuByTc(String tname);//通过老师名寻找所有学生，这一步主要是展示在老师录入和修改成绩的时候，列出所有学生的信息，方便老师知道要改谁的改哪门课

	int addStuGrade(Student stu);//主要是录入/修改学生成绩
}

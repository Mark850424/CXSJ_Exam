package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import user.Student;
import user.Teacher;
import util.DBUtil;

public class StudentDao_impl implements StudentDao {

	private Connection conn;
	private PreparedStatement ps;
	private String sql;

	{
		//获取DBUtril的连接
		try {
			conn = (new DBUtil()).getConnection();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
	}

	@Override
	public List<Student> findByStuName(String name) {
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		List<Student> lis = new ArrayList<Student>();
		ResultSet rs = null;
		try {
			rs = st.executeQuery(
					"SELECT stuid, stuname ,teachname,lessonid,lessonname,lessongrade FROM scginfo WHERE stuname = '"
							+ name + "'");
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		//每次读取一条记录
		while (true) {
			try {
				if (!rs.next())
					break;
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
			try {
				//添加到lis集合中
				lis.add(new Student(rs.getString("stuid"), rs.getString("stuname"), rs.getString("teachname"),
						rs.getString("lessonid"), rs.getString("lessonname"), rs.getString("lessongrade")));
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
		}
		return lis;
	}

	//通过学生名找学生，只不过仅返回单条记录
	public Student findStu(String name) {
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		ResultSet rs = null;
		try {
			rs = st.executeQuery(
					"SELECT stuid, stuname ,teachname,lessonid,lessonname,lessongrade FROM scginfo WHERE stuname = '"
							+ name + "'");
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		while (true) {
			try {
				if (!rs.next())
					break;
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
			try {
				return new Student(rs.getString("stuid"), rs.getString("stuname"), rs.getString("teachname"),
						rs.getString("lessonid"), rs.getString("lessonname"), rs.getString("lessongrade"));//这个语句和返回的lis就是不一样的
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
		}
		return null;
	}

	@Override
	//返回学生课程集合
	public List<Teacher> findAllLesson() {
		Statement st = null;
		try {
			st = conn.createStatement();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		List<Teacher> lis = new ArrayList<Teacher>();
		ResultSet rs = null;
		try {
			rs = st.executeQuery("SELECT teachid, teachname ,lessonid,lessonname FROM tlinfo");
		} catch (SQLException throwables) {
			throwables.printStackTrace();
		}
		//每次读取一条记录
		while (true) {
			try {
				if (!rs.next())
					break;
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
			try {
				//添加到lis集合中
				lis.add(new Teacher(rs.getString("teachid"), rs.getString("teachname"), rs.getString("lessonid"),
						rs.getString("lessonname")));
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}
		}
		return lis;
	}

	//选课，相当于增加信息到数据库的scginfo
	@Override
	public int addChsLesson(String sid, String sname, String tname, String lid, String lname) {
		//sql = "INSERT INTO scginfo(stuid,stuname,teachname,lessonid,lessonname) VALUES(?,?,?,?,?,?)";
		//		sql = "INSERT INTO scginfo(stuid,stuname,teachname,lessonid,lessonname)" + "SELECT '" + sid + "','" + sname
		//				+ "','" + tname + "','" + lid + "','" + lname + "' FROM scginfo"
		//				+ "WHERE NOT EXISTS(SELECT * FROM scginfo WHERE stuname='" + sname + "' AND lessonname='" + lname
		//				+ "') limit 1";
		sql = "INSERT INTO scginfo(stuid,stuname,teachname,lessonid,lessonname) SELECT '" + sid + "','" + sname + "','"
				+ tname + "','" + lid + "','" + lname
				+ "' FROM scginfo WHERE NOT EXISTS(SELECT * FROM scginfo WHERE stuname='" + sname + "' AND lessonname='"
				+ lname + "') limit 1";
		try {
			//使用prepareStatement动态添加参数
			ps = conn.prepareStatement(sql);
			return ps.executeUpdate();
		} catch (SQLException throwables) {
			throwables.printStackTrace();
			return 0;
		}
	}

}

package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.StudentService_impl;

/**
 * Servlet implementation class ChsLstoDBController
 */
@WebServlet(name = "/ChsLstoDBServlet", urlPatterns = "/ChsLstoDBController")
public class ChsLstoDBController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ChsLstoDBController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html;charset=utf-8");
		String a = (String) req.getSession().getAttribute("Stuid");
		String b = (String) req.getSession().getAttribute("Stdtname");
		StudentService_impl sserv = new StudentService_impl();
		String c = req.getParameter("fortname");
		String d = req.getParameter("forlid");
		String e = req.getParameter("forlname");
		int row = sserv.addChsLesson(a, b, c, d, e);
		if (row == 1) {
			//执行成功，刷新页面
			resp.sendRedirect("SBrowseGrade.jsp");
		} else {
			PrintWriter pw = resp.getWriter();
			resp.setContentType("text/html;charset=utf-8");
			pw.println("<script>alert('选课失败，您已选过此课，不可更改，请返回');window.history.back(-1); </script>");
		}

		//req.getRequestDispatcher("SChooseLson.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}

}

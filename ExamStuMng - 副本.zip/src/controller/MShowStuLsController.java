package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ManagerDao;
import dao.ManagerDao_impl;
import dao.StudentDao;
import dao.StudentDao_impl;
import user.StudentforUPDT;
import user.Teacher;

/**
 * Servlet implementation class MShowStuLsController
 */
@WebServlet(name = "/MShowStuLsServlet", urlPatterns = "/MShowStuLsController")
public class MShowStuLsController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MShowStuLsController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");

		ManagerDao dao = new ManagerDao_impl();
		List<StudentforUPDT> lis = dao.findAllStuLson();
		req.getSession().setAttribute("stulslist", lis);

		StudentDao dao1 = new StudentDao_impl();
		List<Teacher> lis1 = dao1.findAllLesson();
		req.getSession().setAttribute("cllist1", lis1);//传给教务人员修改课表时，可以参照此表看有哪些老师/课程可选
		req.getRequestDispatcher("MUdtChoosLson.jsp").forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}

}

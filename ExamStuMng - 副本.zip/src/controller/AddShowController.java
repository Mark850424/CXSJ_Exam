package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.TeacerDao_impl;
import dao.TeacherDao;
import user.Student;

/**
 * Servlet implementation class AddShowController
 */
@WebServlet(name = "/AddShowServlet", urlPatterns = "/AddShowController")
public class AddShowController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddShowController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=utf-8");
		String a = (String) req.getSession().getAttribute("Tchrname");//要转化为String类型，因为原本是个Object型
		TeacherDao dao = new TeacerDao_impl();
		List<Student> lis = dao.findAllStuByTc(a);
		req.setAttribute("stulist1", lis);
		req.getRequestDispatcher("TAddGrade.jsp").forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}

}

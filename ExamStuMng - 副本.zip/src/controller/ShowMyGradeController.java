package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.StudentDao;
import dao.StudentDao_impl;
import user.Student;

/**
 * Servlet implementation class ShowMyGradeController
 */
@WebServlet(name = "/ShowMyGradeServlet", urlPatterns = "/ShowMyGradeController")
public class ShowMyGradeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ShowMyGradeController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=utf-8");
		//String a = req.getParameter("Tchrname");
		//这里用session进行传值，将最开始输入在登陆页面的用户名传进来进行后续教师姓名的匹配
		String a = (String) req.getSession().getAttribute("Stdtname");//要转化为String类型，因为原本是个Object型
		//System.out.print(a);//测试得到的值
		StudentDao dao = new StudentDao_impl();
		List<Student> lis = dao.findByStuName(a);
		req.setAttribute("gralist", lis);
		req.getRequestDispatcher("SBrowseGrade.jsp").forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}

}

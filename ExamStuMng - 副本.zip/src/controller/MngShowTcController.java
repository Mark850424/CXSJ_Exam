package controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.ManagerDao;
import dao.ManagerDao_impl;
import dao.StudentDao;
import dao.StudentDao_impl;
import user.Manager;
import user.Teacher;

/**
 * Servlet implementation class MngShowTcController
 */
@WebServlet(name = "/MngShowTcServlet", urlPatterns = "/MngShowTcController")
public class MngShowTcController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MngShowTcController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//设置编码格式
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");

		ManagerDao dao = new ManagerDao_impl();
		List<Manager> lis = dao.findAllTeacher();
		req.getSession().setAttribute("Tlist", lis);//传入可选老师列表

		StudentDao dao1 = new StudentDao_impl();
		List<Teacher> lis1 = dao1.findAllLesson();
		req.getSession().setAttribute("cllist", lis1);//传给教务已经录入教师课程jsp
		req.getRequestDispatcher("MAddTcLson.jsp").forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}

}

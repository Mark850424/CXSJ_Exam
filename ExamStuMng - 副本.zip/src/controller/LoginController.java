package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.TeacerDao_impl;
import dao.TeacherDao;
import service.LoginService_impl;
import service.ManagerService_impl;
import service.StudentService_impl;
import service.TeacherService_impl;
import user.Teacher;

/**
 * Servlet implementation class LoginController
 */
//注解要写好，跳转用的是urlPatterns“/”后的名称，有点像web.xml配置的
//不写WebServlet注解的话就配置web.xml，同样用的也是url-patterns的值
@WebServlet(name = "LoginServlet", urlPatterns = "/LoginController")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public LoginController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doPost(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//设置编码格式
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=utf-8");
		String a = req.getParameter("Username");//前台Login.html传来的用户名
		String b = req.getParameter("Password");//……传来的密码
		String c = req.getParameter("Usertype");//……传来的用户类型
		//System.out.print("v:" + c);//测试是否获得用户选择的身份
		LoginService_impl service = new LoginService_impl();
		TeacherService_impl tservice = new TeacherService_impl();
		StudentService_impl sservice = new StudentService_impl();
		ManagerService_impl mservice = new ManagerService_impl();
		//System.out.print(service.checkUsertype(a) + " " + c);
		PrintWriter pw = resp.getWriter();
		if (service.checkUsertype(a) == -1) {//说明没有这个用户
			pw.println("<h1>用户不存在</h1>");
		} else {//说明有用户，现在要查看身份是否匹配了
			//通过用户名找到了用户，接下来看看用户身份对不对
			if (((service.checkUsertype(a) == 0) && c.equals("教务人员"))
					|| ((service.checkUsertype(a) == 1) && c.equals("教师"))
					|| ((service.checkUsertype(a) == 2) && c.equals("学生")))//说明名字和身份匹配
			{
				switch (service.checkPassword(a, b)) {
				case 2://这一步也可以省去因为其实到这里说明是有用户的
					pw.println("<h1>用户不存在</h1>");
					break;
				case 1:
					pw.println("<h1>密码错误，登陆失败</h1>");
					break;
				case 0://登录成功
					if (service.checkUsertype(a) == 0) {
						req.getSession().setAttribute("Mngname", mservice.getManager(a).getMngname());//教务人员主界面“欢迎”
						req.getRequestDispatcher("managerPage.jsp").forward(req, resp);
					} else if (service.checkUsertype(a) == 1) {
						//以下注释的都是返回单条记录
						//						User user = service.getUser(a);
						//						req.setAttribute("username", user.getUsername());
						//						req.setAttribute("userid", user.getUserid());
						//						Teacher tl = tservice.getLesson(user.getUsername());
						//						req.setAttribute("lessonid", tl.getLessonId());
						//						req.setAttribute("lessonname", tl.getLessonName());
						TeacherDao dao = new TeacerDao_impl();
						List<Teacher> lis = dao.findAllLesson(a);
						req.setAttribute("tName", tservice.getTeacher(a).getTeachName());//传入“×××欢迎您”
						req.setAttribute("leslist", lis);//传入显示该老师所教课程列表
						//用Session传值，可以比直接setAttribute保存更久，这里保存后将用在后续老师点击一些按钮后查询学生情况
						req.getSession().setAttribute("Tchrname", tservice.getTeacher(a).getTeachName());
						req.getRequestDispatcher("teacherPage.jsp").forward(req, resp);
					} else {
						//StudentDao dao = new StudentDao_impl();
						//List<Student> list = dao.findByStuName(a);
						req.getSession().setAttribute("Stdtname", sservice.getStudent(a).getStuname());//选课和学生端主界面“欢迎”用
						req.getSession().setAttribute("Stuid", sservice.getStudent(a).getStuid());//选课用
						req.getRequestDispatcher("studentPage.jsp").forward(req, resp);
					}
					break;
				}
			} else {
				pw.println("<h1>身份不匹配或用户不存在</h1>");
			}
		}

	}

}

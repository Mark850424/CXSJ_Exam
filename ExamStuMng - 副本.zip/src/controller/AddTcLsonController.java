package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.ManagerService_impl;
import user.Teacher;

/**
 * Servlet implementation class AddTcLsonController
 */
@WebServlet(name = "/AddTcLsonServlet", urlPatterns = "/AddTcLsonController")
public class AddTcLsonController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddTcLsonController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=utf-8");
		ManagerService_impl serv = new ManagerService_impl();
		String a = req.getParameter("tcid");
		String b = req.getParameter("tcn");
		String c = req.getParameter("lsid");
		String d = req.getParameter("lsn");
		int row = serv.addTcLson(new Teacher(a, b, c, d));
		if (row == 1) {
			//执行成功，刷新页面
			resp.sendRedirect("MAddTcLson.jsp");
		} else {
			PrintWriter pw = resp.getWriter();
			resp.setContentType("text/html;charset=utf-8");
			pw.println("<script>alert('录入教师任课信息失败，请返回');window.history.back(-1); </script>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}

}

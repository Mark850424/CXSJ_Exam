package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.ManagerService_impl;
import user.StudentforUPDT;

/**
 * Servlet implementation class MUpdtStuLsonController
 */
@WebServlet(name = "/MUpdtStuLsonServlet", urlPatterns = "/MUpdtStuLsonController")
public class MUpdtStuLsonController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public MUpdtStuLsonController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");

		ManagerService_impl serv = new ManagerService_impl();
		String a = req.getParameter("tbId");
		String b = req.getParameter("sId");
		String c = req.getParameter("sNm");
		String d = req.getParameter("tNm");
		String e = req.getParameter("lId");
		String f = req.getParameter("lNm");
		int row = serv.updateStuLson(new StudentforUPDT(Integer.parseInt(a), b, c, d, e, f, null));
		if (row == 1) {
			resp.sendRedirect("MUdtChoosLson.jsp");
		} else {
			PrintWriter pw = resp.getWriter();
			resp.setContentType("text/html;charset=utf-8");
			pw.println("<script>alert('更新失败，没有这条学生选课记录，请返回');window.history.back(-1); </script>");
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}

}

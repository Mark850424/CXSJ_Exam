package controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.TeacerDao_impl;
import user.Student;

/**
 * Servlet implementation class AddStuGradeController
 */
@WebServlet(name = "/AddStuGradeServlet", urlPatterns = "/AddStuGradeController")
public class AddStuGradeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddStuGradeController() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=utf-8");
		//		String a = (String) req.getSession().getAttribute("Tchrname");//要转化为String类型，因为原本是个Object型
		//		TeacherDao dao = new TeacerDao_impl();
		//		List<Student> lis = dao.findAllStuByTc(a);
		//		req.setAttribute("stulist1", lis);
		//将输入的成绩录入信息获取并添加到数据库
		TeacerDao_impl serv = new TeacerDao_impl();
		String b = req.getParameter("Stuid");
		String c = req.getParameter("Stuname");
		String d = req.getParameter("Teachname");
		String e = req.getParameter("Lesid");
		String f = req.getParameter("Lesname");
		String g = req.getParameter("Stugrade");
		int row = serv.addStuGrade(new Student(b, c, d, e, f, g));
		if (row == 1) {
			//执行成功，刷新页面
			resp.sendRedirect("TAddGrade.jsp");
		} else {
			PrintWriter pw = resp.getWriter();
			resp.setContentType("text/html;charset=utf-8");
			pw.println("<script>alert('录入/修改学生成绩失败，请返回');window.history.back(-1); </script>");
		}
		//req.getRequestDispatcher("TBrowseGrade.jsp").forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(req, resp);
	}

}

package user;

public class Manager {
	public String mngid, mngname;

	public String getMngid() {
		return mngid;
	}

	public void setMngid(String mngid) {
		this.mngid = mngid;
	}

	public String getMngname() {
		return mngname;
	}

	public void setMngname(String mngname) {
		this.mngname = mngname;
	}

	public Manager() {
	}

	public Manager(String _mngid, String _mngname) {
		this.mngid = _mngid;
		this.mngname = _mngname;
	}

	//这里即是返回前端需要引用的变量名，所以MAddTcLson.jsp的Tlist变量属性为mngid和mngname
	@Override
	public String toString() {
		return mngid + " " + mngname;
	}
}

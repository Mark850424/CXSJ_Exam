package user;

/**
 * 这个用户实体类和Student几乎一样，多了一个tableid的索引，主要是修改
 * 学生选课的时候作为区分，因为一个学生可能选了多门课，如果没有tableid 的索引区分唯一记录，修改的时候会把这个学生所选的所有课都修改掉（所以
 * 注意这里的数据库设计）
 * 
 * @author M LitYauthent
 *
 */
public class StudentforUPDT {
	String stuid, stuname, teachname, lessonid, lessonname, lessongrade;
	int tableid;

	public int getTableid() {
		return tableid;
	}

	public void setTableid(int tableid) {
		this.tableid = tableid;
	}

	public String getStuid() {
		return stuid;
	}

	public void setStuid(String stuid) {
		this.stuid = stuid;
	}

	public String getStuname() {
		return stuname;
	}

	public void setStuname(String stuname) {
		this.stuname = stuname;
	}

	public String getTeachname() {
		return teachname;
	}

	public void setTeachname(String teachname) {
		this.teachname = teachname;
	}

	public String getLessonid() {
		return lessonid;
	}

	public void setLessonid(String lessonid) {
		this.lessonid = lessonid;
	}

	public String getLessonname() {
		return lessonname;
	}

	public void setLessonname(String lessonname) {
		this.lessonname = lessonname;
	}

	public String getLessongrade() {
		return lessongrade;
	}

	public void setLessongrade(String lessongrade) {
		this.lessongrade = lessongrade;
	}

	public StudentforUPDT() {
	}

	public StudentforUPDT(int _tableid, String _stuid, String _stuname, String _teachname, String _lessonid,
			String _lessonname, String _lessongrade) {
		this.tableid = _tableid;
		this.stuid = _stuid;
		this.stuname = _stuname;
		this.teachname = _teachname;
		this.lessonid = _lessonid;
		this.lessonname = _lessonname;
		this.lessongrade = _lessongrade;
	}

	//这里即是返回前端需要引用的变量名
	@Override
	public String toString() {
		return tableid + " " + stuid + " " + stuname + " " + teachname + " " + lessonid + " " + lessonname + " "
				+ lessongrade;
	}
}

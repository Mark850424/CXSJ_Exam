package user;

public class Student {
	public String stuid, stuname, teachname, lessonid, lessonname, lessongrade;

	public String getStuid() {
		return stuid;
	}

	public void setStuid(String stuid) {
		this.stuid = stuid;
	}

	public String getStuname() {
		return stuname;
	}

	public void setStuname(String stuname) {
		this.stuname = stuname;
	}

	public String getTeachname() {
		return teachname;
	}

	public void setTeachname(String teachname) {
		this.teachname = teachname;
	}

	public String getLessonid() {
		return lessonid;
	}

	public void setLessonid(String lessonid) {
		this.lessonid = lessonid;
	}

	public String getLessonname() {
		return lessonname;
	}

	public void setLessonname(String lessonname) {
		this.lessonname = lessonname;
	}

	public String getLessongrade() {
		return lessongrade;
	}

	public void setLessongrade(String lessongrade) {
		this.lessongrade = lessongrade;
	}

	public Student() {
	}

	public Student(String _stuid, String _stuname, String _teachname, String _lessonid, String _lessonname,
			String _lessongrade) {
		this.stuid = _stuid;
		this.stuname = _stuname;
		this.teachname = _teachname;
		this.lessonid = _lessonid;
		this.lessonname = _lessonname;
		this.lessongrade = _lessongrade;
	}

	//这里即是返回前端需要引用的变量名
	@Override
	public String toString() {
		return stuid + " " + stuname + " " + teachname + " " + lessonid + " " + lessonname + " " + lessongrade;
	}
}

package user;

/**
 * 数据对象类
 * 
 * @author M LitYauthent
 */
public class User {
	String userid, username, userpassword;
	int usertype;

	public String getUserid() {
		return userid;
	}

	public void setUserid(String userid) {
		this.userid = userid;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getUserpassword() {
		return userpassword;
	}

	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

	public int getUsertype() {
		return usertype;
	}

	public void setUsertype(int usertype) {
		this.usertype = usertype;
	}

	//用户构造函数
	public User() {
	}

	public User(String _userid, String _username, String _userpassword, int _usertype) {
		userid = _userid;
		username = _username;
		userpassword = _userpassword;
		usertype = _usertype;
	}
}

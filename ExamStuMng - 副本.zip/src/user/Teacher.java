package user;

public class Teacher {
	public String teachId, teachName, lessonId, lessonName;

	public String getTeachId() {
		return teachId;
	}

	public void setTeachId(String teachId) {
		this.teachId = teachId;
	}

	public String getTeachName() {
		return teachName;
	}

	public void setTeachName(String teachName) {
		this.teachName = teachName;
	}

	public String getLessonId() {
		return lessonId;
	}

	public void setLessonId(String lessonId) {
		this.lessonId = lessonId;
	}

	public String getLessonName() {
		return lessonName;
	}

	public void setLessonName(String lessonName) {
		this.lessonName = lessonName;
	}

	public Teacher() {
	}

	public Teacher(String _teachid, String _teachname, String _lessonid, String _lessonname) {
		this.teachId = _teachid;
		this.teachName = _teachname;
		this.lessonId = _lessonid;
		this.lessonName = _lessonname;
	}

	//这里即是返回前端需要引用的变量名
	@Override
	public String toString() {
		return teachId + " " + teachName + " " + lessonId + " " + lessonName;
	}

}

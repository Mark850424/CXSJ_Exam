package paged;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import user.StudentforUPDT;
import util.DBUtil;

public class PagedStudent {
	public List<StudentforUPDT> getStuGradeList(int start, int length, String name) {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "SELECT * FROM scginfo WHERE teachname='" + name + "' LIMIT ?, ?";
		List<StudentforUPDT> result = new ArrayList<StudentforUPDT>();
		try {
			//connection = DBUtil.getConnection(); 
			connection = (new DBUtil()).getConnection();// 获取数据库连接
			pstmt = connection.prepareStatement(sql);
			pstmt.setInt(1, start);
			pstmt.setInt(2, length);
			rs = pstmt.executeQuery(); // 执行查询
			while (rs.next()) {
				StudentforUPDT stu = new StudentforUPDT();
				stu.setTableid(rs.getInt("tableid"));
				stu.setStuid(rs.getString("stuid"));
				stu.setStuname(rs.getString("stuname"));
				stu.setTeachname(rs.getString("teachname"));
				stu.setLessonid(rs.getString("lessonid"));
				stu.setLessonname(rs.getString("lessonname"));
				stu.setLessongrade(rs.getString("lessongrade"));

				result.add(stu);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭连接
			if (connection != null) {
				try {
					connection.close();
				} catch (Exception e) {
				}
			}
		}
		return result;
	}

	//获取总条数
	public int totalCount(String name) {
		Connection connection = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		int result = 0;

		try {
			//connection = DBUtil.getConnection(); // 获取数据库连接
			connection = (new DBUtil()).getConnection();
			String sql = "SELECT COUNT(*) from scginfo WHERE teachname='" + name + "'";
			pstmt = connection.prepareStatement(sql);
			rs = pstmt.executeQuery(); // 执行查询
			if (rs.next()) {
				result = rs.getInt(1);//取表中第一列的值
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			// 关闭连接
			if (connection != null) {
				try {
					connection.close();
				} catch (Exception e) {
				}
			}
		}
		return result;
	}
}

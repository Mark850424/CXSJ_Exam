package util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;

/**
 * 数据库连接工具类
 * 
 * @author M LitYauthent
 *
 */
public class DBUtil {
	private DataSource ds;

	//静态代码块 ： 本地程序加载静态资源
	public DBUtil() {
		String file = "jdbc.properties";
		Properties config = new Properties();
		InputStream is = getClass().getResourceAsStream(file);

		try {
			config.load(is);
		} catch (IOException e) {
			e.printStackTrace();
		}
		String driver = config.getProperty("Driver");
		String url = config.getProperty("Url");
		String user = config.getProperty("User");
		String password = config.getProperty("Password");
		//连接池大小
		int size = Integer.parseInt(config.getProperty("size"));
		//最大同时分配数量
		int active = Integer.parseInt(config.getProperty("active"));
		//连接池最少保持空闲连接数
		int idle = Integer.parseInt(config.getProperty("idle"));
		BasicDataSource bs = new BasicDataSource();

		bs.setDriverClassName(driver);
		bs.setUrl(url);
		bs.setUsername(user);
		bs.setPassword(password);
		bs.setInitialSize(size);
		bs.setMaxActive(active);
		bs.setMaxIdle(idle);
		ds = bs;
	}

	public Connection getConnection() throws SQLException {
		return ds.getConnection();
	}

	public static void closeConnection(Connection conn) {
		if (conn != null)
			try {
				conn.close();
			} catch (SQLException throwables) {
				throwables.printStackTrace();
			}

	}
}
